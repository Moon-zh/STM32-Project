#ifndef __G405tf_H
#define __G405tf_H
#include "sys.h"

u8		init_4G(void);
void	RTS_4G(void);

#endif
