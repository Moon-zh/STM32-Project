#include "communication.h"
#include "rs485.h"
#include "delay.h"
#include "Includes.h"
#include "UserHmi.h"
#include "logic.h"
u8 Com_State=0;
u8 s_u8State; //��⴮��3״̬
u8 f_u8State;//��⴮��4״̬
u8 com_conect_state=0;//��������״̬
u8 com3state=0;//����3����״̬
u8 com4state=2;//����4����״̬
u8 startzone;//��������
u8 closezone;//�رշ���
u8 Com3_Send_Count=0;//�ط�����
u8 Com4_Send_Count=0;//�ط�����
u8 Com3_Conect_Error=0;//�ն����Ӵ����־
u8 Com4_Conect_Error=0;//��ˮ�����Ӵ����־
extern Targetred ctargetrcord;//��ǰ�����¼
extern fertaskdata fertasktimedate;//ˮ��ʵʱ���ݶ�ȡ
//��������ΪУ����

u8   s_u8State = 0;
u16 s_u16Pos = 0;
u16 s_u16Length = 0;
u8  f_u8State = 0;
u16 f_u16Pos = 0;
u16 f_u16Length = 0;
u8 com3databuf[9];//����3����
u8 com4databuf[24];//����4���� IO״̬ռ2���ֽڣ�4��������ռ16���ֽ�
u8 send_count=0;//����3���ݷ��ʹ�����ֵ
u8 send4_count=0;//����4���ݷ��ʹ�����ֵ
tagend tagendstr;//�ն�ͨ�Žṹ��
OS_EVENT * ComQMsg;
void* 	ComMsgBlock[4];
OS_MEM* ComPartitionPt;
u8 g_u8ComMsgMem[20][4];
MsgComStruct ComMsg;
u8 ComQInit(void)
{
    INT8U os_err;

    ComQMsg = OSQCreate ( ComMsgBlock, 4);

    if(ComQMsg == (OS_EVENT *)0)
    {
        return 1;
    }

    ComPartitionPt = OSMemCreate (
                         g_u8ComMsgMem,
                         20,
                         4,
                         &os_err
                     );
    if(os_err != OS_ERR_NONE)
    {
        return 2;
    }
    return 0;
}
u8 DepackReceiveComQ(MsgComStruct * MasterQ)
{
    u8 os_err;
    os_err = OSMemPut(ComPartitionPt, ( void * )MasterQ);
    if(os_err != OS_ERR_NONE)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

u8 PackSendComQ(MsgComStruct* MsgBlk)
{
    INT8U os_err;
    MsgComStruct * MsgTemp = NULL;
    MsgTemp = (MsgComStruct *)OSMemGet(ComPartitionPt,&os_err);
    if(MsgTemp == NULL)
    {
        return 1;
    }
    MsgTemp ->CmdType = MsgBlk->CmdType;
    MsgTemp ->CmdSrc = MsgBlk->CmdSrc;
    MsgTemp ->CmdData[0] = MsgBlk->CmdData[0];
    MsgTemp ->CmdData[1] = MsgBlk->CmdData[1];
    os_err = OSQPost ( ComQMsg,(void*)MsgTemp );
    //������Ϣʧ���ͷ��ڴ�
    if(os_err!=OS_ERR_NONE)
    {
        OSMemPut(ComPartitionPt, ( void * )MsgTemp);
        return 2;
    }
    return 0;
}

void board2com(u8 readwrite,u8 ioadress,u8 iostate)
{
    u8 date[24]= {0XAA,0X55,0X01,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0XA5,0X5A};
    if(readwrite==0)//��
    {
        date[3]=0X03;

    }
    else
    {
        date[3]=0X06;
        date[4]=ioadress;
        date[5]=iostate;
    }
    comSendBuf(COM4,date ,24);
}
void writetagend(u8 zone,u8 state)//Ҫд�ķ���״̬
{
    u8 date[9]= {0xaa,0x55,0,0x6,0x02,0,0,0xa5,0x5a};
    tagendstr.head_h=0xaa;
    tagendstr.head_l=0x55;
    tagendstr.ID=date[2]=(zone-1)/4+1;
    tagendstr.code=date[3]=0x6;
    tagendstr.datanum=0x02;
    tagendstr.solenoidvalve=date[5]=zone-(zone-1)/4*4;//��Ӧ������ŷ�
    tagendstr.solenoidvalve=date[6]=state;
    tagendstr.tail_h=0xa5;
    tagendstr.tail_l=0x5a;
    comSendBuf(COM3,date ,9);
}
void Resetall(u8 zone)//Ҫд�ķ���״̬
{
    u8 date[9]= {0xaa,0x55,0,0x0f,0x02,0,0,0xa5,0x5a};
    tagendstr.head_h=0xaa;
    tagendstr.head_l=0x55;
    tagendstr.ID=date[2]=(zone-1)/4+1;
    tagendstr.code=date[3]=0x6;
    tagendstr.datanum=0x02;
    tagendstr.solenoidvalve=date[5]=zone-(zone-1)/4*4;//��Ӧ������ŷ�
    tagendstr.solenoidvalve=date[6]=0;
    tagendstr.tail_h=0xa5;
    tagendstr.tail_l=0x5a;
    comSendBuf(COM3,date ,9);
}
void readtagend(u8 zone)//Ҫ��������״̬
{
    u8 date[9]= {0xaa,0x55,0,0x03,0x02,0,0,0xa5,0x5a};
    tagendstr.head_h=0xaa;
    tagendstr.head_l=0x55;
    tagendstr.ID=date[2]=(zone-1)/4+1;
    tagendstr.code=date[3]=0x3;
    tagendstr.datanum=0x02;
    tagendstr.solenoidvalve=date[5]=zone-(zone-1)/4*4;//��Ӧ������ŷ�
    tagendstr.solenoidvalve=date[6]=0;
    tagendstr.tail_h=0xa5;
    tagendstr.tail_l=0x5a;
    comSendBuf(COM3,date ,9);
}
u16 verifycom3recviedata(u8 *buffer)
{
    u8 u8Data = 0;
//	GR_U8 u8CountTem = 0 ,u8DataTem;
//	GR_U16 u16CRC ,u16DataLength = 0;
//	u8 u16SUM_Check;

    while ( comGetRxAvailableDataSize(COM3)>0 )
    {
        switch ( s_u8State )
        {
        case STATE_START:
            comGetChar ( COM3 , &u8Data );

            if ( ( u8Data == 0xaa ) && ( s_u16Pos == 0 ) ) //֡ͷ
            {
                buffer[s_u16Pos ++] = u8Data;
            }
            else if ( ( u8Data != 0xAA ) && ( s_u16Pos == 0 ) ) //֡ͷ
            {
                s_u16Pos = 0;
                continue;
            }
            else
            {
                buffer[s_u16Pos ++] = u8Data;
            }

            if(( u8Data != 0x55 ) && ( s_u16Pos == 2 ))
            {
                s_u16Pos = 0;
                return s_u16Pos;
            }
            //s_u16Pos ++;

            if ( ( s_u16Pos == 3 ) && ( buffer[2] == tagendstr.ID ) )
            {
                s_u8State = STATE_1;
            }
            else if ( ( s_u16Pos == 3 ) && ( buffer[2] != tagendstr.ID ) )
            {
                s_u16Pos = 0;
                return s_u16Pos;
            }

            break;
        case STATE_1://�������պ������ݣ�ȫ��������
            comGetChar ( COM3 , &u8Data );
            buffer[s_u16Pos++] = u8Data;

            if ( s_u16Pos > 9 )
            {
                s_u16Pos = 0;
                memset ( com3databuf , 0 , 9 );
                s_u8State = STATE_START;
                return 0;
            }

            if ( s_u16Pos == 9 ) //������
            {
                s_u8State = STATE_START;
//							   u16DataLength = s_u16Length;
                s_u16Length = s_u16Pos;
                s_u16Pos = 0;

                //��֤�������У���
                if ( ( buffer[s_u16Length - 1] == 0x5a ) && ( buffer[s_u16Length - 2]==0xa5 ) )  //
                {
                    return s_u16Length;
                }
                else//ʧ��
                {
                    memset ( com3databuf , 0 , s_u16Length );
                    return 0;
                }
            }

            break;
        default:
            break;
        }
    }

    if ( s_u16Pos > 9 )
    {
        s_u16Pos = 0;
        s_u8State = STATE_START;
    }

    return 0;//û���γ�������һ֡
}
u16 verifycom4recviedata(u8 *buffer)
{
    u8 u8Data = 0;
//	GR_U8 u8CountTem = 0 ,u8DataTem;
//	GR_U16 u16CRC ,u16DataLength = 0;
//	u8 u16SUM_Check;

    while ( comGetRxAvailableDataSize(COM4)>0 )
    {
        switch ( f_u8State )
        {
        case STATE_START:
            comGetChar ( COM4 , &u8Data );

            if ( ( u8Data == 0xaa ) && ( f_u16Pos == 0 ) ) //֡ͷ
            {
                buffer[f_u16Pos ++] = u8Data;
            }
            else if ( ( u8Data != 0xAA ) && ( f_u16Pos == 0 ) ) //֡ͷ
            {
                f_u16Pos = 0;
                continue;
            }
            else
            {
                buffer[f_u16Pos ++] = u8Data;
            }

            if(( u8Data != 0x55 ) && ( f_u16Pos == 2 ))
            {
                f_u16Pos = 0;
                return f_u16Pos;
            }
            //s_u16Pos ++;

            if ( ( f_u16Pos == 3 ) && ( buffer[2] == 1 ) )
            {
                f_u8State = STATE_1;
            }
            else if ( ( f_u16Pos == 3 ) && ( buffer[2] != 1 ) )
            {
                f_u16Pos = 0;
                return f_u16Pos;
            }

            break;
        case STATE_1://�������պ������ݣ�ȫ��������
            comGetChar ( COM4 , &u8Data );
            buffer[f_u16Pos++] = u8Data;

            if ( f_u16Pos > 24 )
            {
                f_u16Pos = 0;
                memset ( com4databuf , 0 , 24 );
                f_u8State = STATE_START;
                return 0;
            }

            if ( f_u16Pos ==24) //������
            {
                f_u8State = STATE_START;
//							   u16DataLength = s_u16Length;
                f_u16Length = f_u16Pos;
                f_u16Pos = 0;

                //��֤�������У���
                if ( ( buffer[f_u16Length - 1] == 0x5a ) && ( buffer[f_u16Length - 2]==0xa5 ) )  //
                {
                    return f_u16Length;
                }
                else//ʧ��
                {
                    memset ( com4databuf , 0 , f_u16Length );
                    return 0;
                }
            }

            break;
        default:
            break;
        }
    }

    if ( f_u16Pos > 24 )
    {
        f_u16Pos = 0;
        f_u8State = STATE_START;
    }

    return 0;//û���γ�������һ֡
}
void  DepackCom3Data ( void )
{
    u8 u8SourceDataLength , u8CMD;
    u8SourceDataLength = verifycom3recviedata ( com3databuf );

    if ( u8SourceDataLength != 0 )
    {
        u8CMD = com3databuf[3];

        switch ( u8CMD )
        {
        case 3:

            send_count=0;
            break;
        case CMD_RETURN_REAL_TIME_DATA:
            com3state=4;//�˴�д�������
            send_count=0;
            break;
        default :
            break;
        }
    }
}
void  DepackCom4Data ( void )
{
    u8 u8SourceDataLength , i , u8CMD;
    u8SourceDataLength = verifycom4recviedata ( com4databuf );

    if ( u8SourceDataLength != 0 )
    {
        u8CMD = com4databuf[3];

        switch ( u8CMD )
        {
        case 3:
            for(i=6; i<22; i++)
            {
                fertasktimedate.flowerdatabuf[i-6]=com4databuf[i];
            }
//		    com4state=0;//�˴�д�������
            send4_count=0;
            break;
        case CMD_RETURN_REAL_TIME_DATA:
            com4state=2;//�˴�д�������
            send4_count=0;
            break;
        default :
            break;
        }
    }
}

void CHECKCtrl_task(void *pdata)
{
    u8 os_err;
    pdata=pdata;
    MsgComStruct * pMsgBlk = NULL;
    MsgComStruct Msgtemp;
    MsgComStruct MsgtempBlk;
//	MsgStruct Msgtemp1;
    MsgStruct MsgtempBlk1;
    //OS_CPU_SR  cpu_sr;
    ComQInit();
    while(1)
    {
        delay_ms(300);
        if(com3state==4)//���ն�����֮���ٿ�ʼ����
            Com3_Send_Count++;
        if(com4state==2)//�뿨2����֮���ٿ�ʼ����
            Com4_Send_Count++;
        DepackCom3Data ();
        DepackCom4Data ();
        switch(com3state)
        {
        case 1: //�رշ���
            send_count++;
            writetagend(closezone,0);
            break;
        case 2://��������
            send_count++;
            writetagend(startzone,1);
        case 3:
            send_count++;
            Resetall(closezone);
            break;
        case 4://������ȡ
            if(Com3_Send_Count>=4)
            {   send_count++;
                Com3_Send_Count=0;
                MsgtempBlk.CmdType = COM_READ; //������Ϣ����״̬����������
                MsgtempBlk.CmdData[0]= 1;//���ģʽ
                PackSendComQ(&MsgtempBlk);
            }
            break;
        default:
            break;


        }
        switch(com4state)
        {
        case 1: //������ŷ�
            send4_count++;
            board2com(1,ctargetrcord.trecord.fer_onoff,ctargetrcord.trecord.fer_chanle);//ѡ��Ҫ������
            break;

        case 2://������ȡ
            if(Com4_Send_Count>=5)
            {
                Com4_Send_Count=0;
                send4_count++;
                MsgtempBlk.CmdType = COM_READ; //������Ϣ����״̬����������
                MsgtempBlk.CmdData[0]= 2;//����4��������
                PackSendComQ(&MsgtempBlk);
            }
            break;
        default:
            break;


        }
        if((send_count>20)&&(Com3_Conect_Error==0))//���ʹ�������10��
        {
            com3state=0; //������ѭ��
            Com3_Conect_Error=1;
            send_count=0;
            MsgtempBlk1.CmdType = MSG_ALARM; //������Ϣ����״̬����������
            MsgtempBlk1.CmdData[0]= PRESS_BUTTON_ERROR;//ˮ������
            PackSendMasterQ(&MsgtempBlk1);	 		        //ֹͣ����

        }
        else if((send_count>20)&&(Com3_Conect_Error==1))
        {
            com3state=0; //������ѭ��
            send_count=0;
            Com3_Conect_Error=0;

        }

        if((send4_count>10)&&(Com4_Conect_Error==0))//���ʹ�������10��
        {
            com4state=0;
            send4_count=0;
            Com4_Conect_Error=1;
            MsgtempBlk1.CmdType = MSG_ALARM; //������Ϣ����״̬����������
            MsgtempBlk1.CmdData[0]= PRESS_BUTTON_ERROR;//ˮ������
            PackSendMasterQ(&MsgtempBlk1);	 		        //ֹͣ����

        }
        else if((send4_count>10)&&(Com4_Conect_Error==1))
        {
            com4state=0; //������ѭ��
            send4_count=0;
            Com4_Conect_Error=0;

        }

        pMsgBlk = ( MsgComStruct *) OSQPend ( ComQMsg,
                                              10,
                                              &os_err );


        if(os_err == OS_ERR_NONE)
        {
            memcpy((u8*)&Msgtemp,(u8*)pMsgBlk,sizeof(MsgComStruct) );
            DepackReceiveComQ(pMsgBlk);
            switch(Msgtemp.CmdType)
            {
            case COM_READ:
                if(Msgtemp.CmdData[0]==1)//����3��
                {
                    readtagend(startzone); //��Ҫ�������� �ն�����Ҫ��

                }
                else if(Msgtemp.CmdData[0]==2)//����4��
                {
                    com4state =2;
                    board2com(0,ctargetrcord.trecord.fer_onoff,ctargetrcord.trecord.fer_chanle);//ѡ��Ҫ������

                }
                break;
            case COM_WRITE:
                if(Msgtemp.CmdData[0]==1)//����3д
                {
                    if(Msgtemp.CmdData[1]==1) //�رշ���
                    {
                        Com3_Send_Count=0;//��������ʱ
                        com3state =1;
                        send_count++;
                        writetagend(closezone,0);

                    }
                    else if(Msgtemp.CmdData[1]==2)//��������
                    {
                        Com3_Send_Count=0;//��������ʱ
                        send_count++;
                        com3state =2;
                        writetagend(startzone,1);


                    }
                    else if(Msgtemp.CmdData[1]==5)//ȫ�ط���
                    {


                    }

                }
                else if(Msgtemp.CmdData[0]==2)//д����4
                {
                    if(Msgtemp.CmdData[1]==1) //��������
                    {
                        Com4_Send_Count=0;//��������ʱ
                        com4state =1;
                        send4_count++;
                        board2com(1,ctargetrcord.trecord.fer_onoff,ctargetrcord.trecord.fer_chanle);//ѡ��Ҫ������

                    }
                    if(Msgtemp.CmdData[1]==4) //�رշ���
                    {
                        Com4_Send_Count=0;//��������ʱ
                        com4state =1;
                        send4_count++;
                        board2com(1,0,ctargetrcord.trecord.fer_chanle);//ѡ��Ҫ������

                    }
                    if(Msgtemp.CmdData[1]==3) //ȫ�ط���
                    {
                        Com4_Send_Count=0;//��������ʱ
                        com4state =1;
                        send4_count++;
                        board2com(1,2,0);//ѡ��Ҫ������

                    }
                }
                break;



            }
        }


    }
}

